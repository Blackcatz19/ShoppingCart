import {
  Component,
  Input,
  OnChanges,
  OnInit,
  SimpleChanges,
} from '@angular/core';
import { Router } from '@angular/router';
import { MainService } from '../main.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.scss'],
})
export class ProductListComponent implements OnInit {
  @Input() products: any = [];

  constructor(private mainservice: MainService, private router: Router) {}

  ngOnInit(): void {}
  
  navigate_To_Details(product: any) {
    this.mainservice.send_data(product);
    this.router.navigate(['product-details']);
  }
}
