import { Component, OnInit } from '@angular/core';
import { MainService } from '../main.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cart-page',
  templateUrl: './cart-page.component.html',
  styleUrls: ['./cart-page.component.scss'],
})
export class CartPageComponent implements OnInit {
  cart_list: any[] = [];
  total_price: number = 0;
  curr_user: string;
  constructor(private main_service: MainService,private router:Router) {
    this.curr_user = localStorage.getItem('curr_user') as string;
    this.cart_list = JSON.parse(
      localStorage.getItem(this.curr_user + 'cart') as string
    );
    if(this.cart_list)
    this.total_price = this.calculate_TotalPrice()();
  }

  ngOnInit(): void {}
  reduce_Qty(item: any, totalPrice: Function) {
    this.cart_list.map((cart_items) => {
      if (cart_items.name === item.name) {
        if (cart_items.qty > 1) --cart_items.qty;
      }
    });
    localStorage.setItem(this.curr_user +"cart", JSON.stringify(this.cart_list));
    this.main_service.set_cartCount(this.cart_list);
    this.total_price = totalPrice();
  }
  add_Qty(item: any, totalPrice: Function) {
    this.cart_list.map((cart_items) => {
      if (cart_items.name === item.name) {
       ++cart_items.qty;
      }
    });
    localStorage.setItem(this.curr_user +"cart", JSON.stringify(this.cart_list));
    this.main_service.set_cartCount(this.cart_list);
    this.total_price = totalPrice();
  }
  On_remove(item: any, totalPrice: Function) {
    this.cart_list.splice(this.cart_list.indexOf(item), 1);
    this.total_price = totalPrice();
    localStorage.setItem(this.curr_user +"cart", JSON.stringify(this.cart_list));
    this.main_service.set_cartCount(this.cart_list);
  }
  calculate_TotalPrice(): Function {
    let total = 0;
    return () => {
      this.cart_list.map((item) => {
        total += item.qty * item.price;
      });
      return total;
    };
  }
  navigate_To_Details(product: any) {
    this.main_service.send_data(product);
    this.router.navigate(['product-details']);
  }
}
