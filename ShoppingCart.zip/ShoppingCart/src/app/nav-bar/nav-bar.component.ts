import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { MainService } from '../main.service';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.scss'],
})
export class NavBarComponent implements OnInit {
  curr_user: string;
  cart_list: any;
  cart_ItemCount: number = 0;
  subscription: Subscription;
  constructor(private main_service: MainService, private router:Router) {
    this.curr_user = localStorage.getItem('curr_user') as string;
    
    this.subscription = main_service.get_cartCount().subscribe((count) => {
      this.cart_list = JSON.parse(localStorage.getItem(this.curr_user+"cart") as string);
      if (count) {
        this.cart_ItemCount = count;
      } else {
        if (this.cart_list && this.cart_list.length) {
          this.cart_list.map((items: any) => {
            this.cart_ItemCount += items.qty;
          });
        }
        else{
          this.cart_ItemCount = 0;
        }
      }
    });
  }
  signOut() {
    localStorage.setItem('curr_user', '');
    this.curr_user = '';
    this.cart_ItemCount = 0;

this.router.navigate(['signin']);
  }

  ngOnInit(): void {}
}
