import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class MainService {
  private subject = new Subject<any>();
  private behaviour_sub = new BehaviorSubject<any>(null);
  private behaviour_cartItemcount = new BehaviorSubject<any>(null);
  private Current_user!: string;
  constructor(private http: HttpClient) {}

  getProducts() {
    return this.http.get('/assets/Data/products.json');
  }
  send_data(curr_obj: any) {
    this.behaviour_sub.next(curr_obj);
  }
  get_data(): Observable<any> {
    return this.behaviour_sub.asObservable();
  }

  set_cartCount(Items: any) {
    let Items_count = 0;
    Items.map((data: any) => {
      Items_count += data.qty;
    });
    this.behaviour_cartItemcount.next(Items_count);
  }
  get_cartCount() {
    return this.behaviour_cartItemcount.asObservable();
  }
  set_curr_user(usr_Id:string){
    this.Current_user = usr_Id;
  }
  get_curr_usr(){
    return this.Current_user;
  }
}
