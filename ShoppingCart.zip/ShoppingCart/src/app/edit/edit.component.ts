import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { MainService } from '../main.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.scss'],
})
export class EditComponent implements OnInit {
  @Input() product: any;
  @ViewChild('addToCart')btn_addToCart!:ElementRef;
  product_Qty = 1;
  items: Object[] = [];
  constructor(private router: Router, private main_service: MainService) {}

  ngOnInit(): void {}
  reduce_Qty() {
    if (this.product_Qty > 1) --this.product_Qty;
  }
  add_Qty() {
    ++this.product_Qty;
  }
  add_To_cart(product: any) {
    let curr_user = localStorage.getItem("curr_user");
    if(curr_user === ''){
      alert("Please SignIn for Add To Cart");
      return;
    }
    let prv_items: [] = JSON.parse(
      localStorage.getItem(curr_user + 'cart'
      ) as string
    );
    if(!prv_items){
      return;
    }

    if (prv_items.length == 0) {
      
      this.items.push({
        name: product.name,
        img_url: product.img_url,
        description:product.description,
        qty: this.product_Qty,
        price: product.price,
      });
    } else {
      this.items = [];
      let already_exist = false;
      prv_items.map((ele: any) => {
        if (ele.name == product.name) {
          ele.qty += this.product_Qty;
          already_exist = true;
        }
        this.items.push(ele);
      });
      if (!already_exist) {
        this.items.push({
          name: product.name,
          img_url: product.img_url,
          description:product.description,
          qty: this.product_Qty,
          price: product.price,
        });
      }
    }
    
    localStorage.setItem(curr_user + 'cart',
      JSON.stringify(this.items)
    );
    this.main_service.set_cartCount(this.items);
 
      alert("Item Added to cart");
     
  }
  navigate_To_cart(product: any) {
    this.router.navigate(['cart']);
  }
}
