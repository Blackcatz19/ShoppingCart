import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { HomePageComponent } from '../home-page/home-page.component';
import { MainService } from '../main.service';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.scss'],
})
export class SigninComponent implements OnInit {
  submitted = false;
  signin_form = new FormGroup({
    user_name: new FormControl('', Validators.required),
    password: new FormControl('', Validators.required),
  });
  constructor(private route: Router, private main_service: MainService) {}

  ngOnInit(): void {}
  cart: Object[] = [];
  onSubmit() {
    this.submitted = true;

    if (this.signin_form.status == 'VALID') {
      let data = localStorage.getItem(this.signin_form.value.user_name);
      let usr_details = JSON.parse(data as string);
      if (
        this.signin_form.value.user_name == usr_details.userId &&
        this.signin_form.value.password == usr_details.password
      ) {
        localStorage.setItem('curr_user', this.signin_form.value.user_name);
        localStorage.setItem(
          this.signin_form.value.user_name + 'cart',
          JSON.stringify(this.cart)
        );
        this.route.navigate(['']);
      } else {
        alert('UserID or password invalid');
      }
    } else if (this.signin_form.status == 'INVALID') {
      localStorage.setItem('curr_user', '');
    }
  }

  forget_password(userID: string) {
    let user_details = JSON.parse(localStorage.getItem(userID) as string);
    if (user_details) {
      this.main_service.set_curr_user(user_details.userId)
      this.route.navigate(['forget-password']);
    }
    else{
      alert("user Id Invalid!!")
    }
  }

  get signinFormControl() {
    return this.signin_form.controls;
  }
}
