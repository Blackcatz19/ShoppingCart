import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { MainService } from '../main.service';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.scss']
})
export class HomePageComponent implements OnInit {
  product_list:any = [];
  constructor(private mainservice:MainService,private http:HttpClient) { 
}

  ngOnInit(): void {
    this.mainservice.getProducts().subscribe(data=>{
      this.product_list = data;
    });
  }

}
