import { Component, OnInit, Input } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MainService } from '../main.service';

@Component({
  selector: 'app-forget-password',
  templateUrl: './forget-password.component.html',
  styleUrls: ['./forget-password.component.scss'],
})
export class ForgetPasswordComponent implements OnInit {
   user_Id?: string;
  submitted = false;
  password_form = new FormGroup({
    New_password: new FormControl('', Validators.required),
    Confirm_password: new FormControl('', Validators.required),
  });
  constructor(private router: Router, private main_service:MainService) {}

  ngOnInit(): void {}

  get passwordFormControl() {
    return this.password_form.controls;
  }

  onSubmit() {
    this.user_Id = this.main_service.get_curr_usr()
    if (!this.user_Id) return;
    this.submitted = true;

    if (this.password_form.status == 'VALID') {
      if (
        this.password_form.value.New_password ===
        this.password_form.value.Confirm_password
      ) {
        let user_details = JSON.parse(
          localStorage.getItem(this.user_Id) as string
        );
        if (user_details) {
          user_details.password = this.password_form.value.New_password;
          localStorage.setItem(this.user_Id,JSON.stringify(user_details));
          alert('Password Successfully Changed');
          this.router.navigate(['signin']);
        }
      }
    }
  }
}
