import { Component, OnInit } from '@angular/core';
import { FormGroup,FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.scss']
})
export class RegistrationComponent implements OnInit {

  register_form=new FormGroup({
    user_name: new FormControl('',Validators.required),
    password:new FormControl('',Validators.required),
    confirm_password: new FormControl('',Validators.required)
  });
  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  onSubmit(){
    if(this.register_form.status == "VALID"){
      localStorage.setItem(this.register_form.value.user_name,JSON.stringify({'userId':this.register_form.value.user_name,'password':this.register_form.value.password}));
    this.router.navigate(['']);
    }
  }

}
