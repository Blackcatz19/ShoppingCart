import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CartPageComponent } from './cart-page/cart-page.component';
import { ForgetPasswordComponent } from './forget-password/forget-password.component';
import { HomePageComponent } from './home-page/home-page.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { RegistrationComponent } from './registration/registration.component';
import { SigninComponent } from './signin/signin.component';

const routes: Routes = [{path:'',component:HomePageComponent},
                          {path:'signin',component:SigninComponent},
                          {path:'register',component:RegistrationComponent},
                        {path:'product-details',component:ProductDetailsComponent},
                      {path:'cart',component:CartPageComponent},{path:'forget-password',component:ForgetPasswordComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
