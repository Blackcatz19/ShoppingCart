import { AfterViewInit, Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { MainService } from '../main.service';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.scss']
})
export class ProductDetailsComponent implements OnInit,AfterViewInit {

  subscription:Subscription;
  Product_details:any;

  constructor(private mainservice:MainService,private router:Router) {
    this.subscription = mainservice.get_data().subscribe((res)=>{
      this.Product_details =res;
    });
   }

  ngOnInit(): void {

  }
ngAfterViewInit(): void {
}

}
